import React, { useEffect, useMemo, useRef, useState } from 'react';
import { CheckCircle2, ExternalLink, Save, Smartphone } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import { ClinicalSystemKey } from '../../types';

const FORM_URLS: Partial<Record<ClinicalSystemKey, string>> = {
  headache: '/forms/headache.html',
  urinary: '/forms/urinary.html',
  musculoskeletal: '/forms/musculoskeletal.html',
  gastrointestinal: '/forms/gastrointestinal.html',
};

const FORM_LABELS: Partial<Record<ClinicalSystemKey, string>> = {
  headache: 'Neurological / Headache',
  urinary: 'Urinary System & Prostate',
  musculoskeletal: 'Musculoskeletal System',
  gastrointestinal: 'Gastro-Intestinal System',
};

function deriveSummary(data: Record<string, any>, system: ClinicalSystemKey) {
  const complaintKeys = Object.keys(data).filter(k => /complaint|problem|pain|symptom|condition/i.test(k));
  const arrays = complaintKeys.flatMap(k => Array.isArray(data[k]) ? data[k] : []);
  const direct = complaintKeys.flatMap(k => typeof data[k] === 'string' && data[k] ? [data[k]] : []);
  const chief = [...new Set([...arrays, ...direct])].join(', ');
  const duration = Object.entries(data).find(([k,v]) => /duration/i.test(k) && typeof v === 'string' && v)?.[1] as string || '';
  const sev = Object.entries(data).find(([k,v]) => /severity/i.test(k) && typeof v === 'string' && /mild|moderate|severe/i.test(v))?.[1] as string || 'Moderate';
  const notes = Object.entries(data).filter(([k,v]) => /note|remark|impression|status|other/i.test(k) && typeof v === 'string' && v).map(([k,v])=>`${k}: ${v}`).join(' | ');
  const modalitiesAgg = Object.entries(data).filter(([k,v]) => /aggr|worse/i.test(k) && typeof v === 'string').map(([,v])=>v).filter(Boolean).join(', ');
  const modalitiesAmel = Object.entries(data).filter(([k,v]) => /amel|better|relief/i.test(k) && typeof v === 'string').map(([,v])=>v).filter(Boolean).join(', ');
  return {
    chiefComplaints: chief || `${FORM_LABELS[system] || system} complaints recorded`,
    duration,
    severity: (['Mild','Moderate','Severe'].includes(sev) ? sev : 'Moderate') as 'Mild'|'Moderate'|'Severe',
    modalitiesAggravation: modalitiesAgg,
    modalitiesAmelioration: modalitiesAmel,
    concomitants: '',
    clinicalNotes: notes,
  };
}

export const IntegratedHtmlCaseForm: React.FC<{ system: ClinicalSystemKey }> = ({ system }) => {
  const { selectedPatient, systemForms, saveSystemForm } = useClinic();
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [ready, setReady] = useState(false);
  const [lastAction, setLastAction] = useState('');
  const existing = useMemo(() => selectedPatient ? systemForms.find(f => f.patientId === selectedPatient.id && f.system === system) : undefined, [selectedPatient, systemForms, system]);

  useEffect(() => {
    setReady(false);
    setLastAction('');
  }, [system, selectedPatient?.id]);

  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      const m = event.data || {};
      if (!m || m.system !== system) return;
      if (m.type === 'CASE_FORM_READY') {
        setReady(true);
        iframeRef.current?.contentWindow?.postMessage({
          type: 'INIT_PATIENT',
          patient: selectedPatient,
          date: new Date().toISOString().slice(0,10),
          formData: existing?.data || {},
        }, '*');
      }
      if (m.type === 'CASE_FORM_SAVE') {
        if (!selectedPatient) return;
        const data = m.data || {};
        const summary = deriveSummary(data, system);
        saveSystemForm({ patientId: selectedPatient.id, system, data, ...summary, submittedVia: 'Doctor_Dashboard' });
        setLastAction(m.action === 'submit' ? 'Submitted and integrated into the patient record.' : 'Saved and integrated into the patient record.');
      }
      if (m.type === 'CASE_FORM_CLEAR') setLastAction('Form cleared.');
    };
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, [system, selectedPatient, existing, saveSystemForm]);

  if (!selectedPatient) return null;

  return (
    <div className="space-y-3">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-xs">
          <span className="px-2 py-1 rounded-lg bg-teal-50 text-teal-800 font-bold">Integrated Form</span>
          <span className="text-slate-500">{FORM_LABELS[system]}</span>
          <span className="text-slate-400">•</span>
          <span className="font-semibold text-slate-700">{selectedPatient.name} ({selectedPatient.id})</span>
          {existing && <CheckCircle2 className="w-4 h-4 text-emerald-600" title="Existing case loaded" />}
        </div>
        <div className="flex items-center gap-2 text-[11px] text-slate-500">
          {ready ? <><span className="w-2 h-2 rounded-full bg-emerald-500" /> Connected to main patient record</> : 'Loading form…'}
          <button onClick={() => window.open(FORM_URLS[system], '_blank')} className="p-1.5 rounded-lg hover:bg-slate-100" title="Open form separately">
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
      {lastAction && <div className="px-3 py-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2"><Save className="w-4 h-4" />{lastAction}</div>}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <iframe
          ref={iframeRef}
          title={FORM_LABELS[system] || system}
          src={FORM_URLS[system]}
          className="w-full border-0"
          style={{ height: 'calc(100vh - 250px)', minHeight: 760 }}
        />
      </div>
      <div className="flex items-center gap-2 text-[11px] text-slate-500 px-1"><Smartphone className="w-3.5 h-3.5" /> The same patient profile is supplied to the form; Save/Submit writes the complete system case into Case Summary and Repertorisation.</div>
    </div>
  );
};
